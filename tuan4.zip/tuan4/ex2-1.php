<?php
function addHeader($page,$title)
{
    $page .= <<<EOD
<html>
<head>
<title>$title</title>
</head>
<body>
<h1 align="center">$title</h1>
EOD;
    return $page;
}

function addFooter($page,$year,$copyright)
{
    $page .= <<<EOD
    <div align="center">&copy;$year $copyright </div>
    </body>
    </html>
    EOD;
        return $page;
}

$page='';
$page=addHeader($page,'A Prodecural Script');
$page .= <<<EOD
<p align="center">This page was generated with a procedural  
script</p>
EOD;

$page=addFooter($page,date('Y'),'Procedural Designs INC.');

echo $page;


?>
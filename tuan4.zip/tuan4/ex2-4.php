<?php
class Page{
    var $page;
    function Page(){
        $this->page='';
    }
    function addHeader($title)
    {
        $this->page .= <<<EOD
        <html>
        <head>
        <title>$title</title>
        </head>
        <body>
        <h1 align="center">$title</h1>
        EOD;
    }


    function addContent($content){
        $this->page.=$content;
    }

    function addFooter($year,$copyright)
    {
        $this->page .= <<<EOD
        <div align="center">&copy;$year $copyright </div>
        </body>
        </html>
        EOD;
    }

    function get(){
        return $this->page;
    }

    }
?>
<?php
class Page{

    function addHeader($page,$title)
{
    $page .= <<<EOD
<html>
<head>
<title>$title</title>
</head>
<body>
<h1 align="center">$title</h1>
EOD;
    return $page;
}

function addFooter($page,$year,$copyright)
{
    $page .= <<<EOD
    <div align="center">&copy;$year $copyright </div>
    </body>
    </html>
    EOD;
        return $page;
}
}



?>
<?php
class Page{

    function addHeader($page,$title)
{
    $page .= <<<EOD
<html>
<head>
<title>$title</title>
</head>
<body>
<h1 align="center">$title</h1>
EOD;
    return $page;
}

function addFooter($page,$year,$copyright)
{
    $page .= <<<EOD
    <div align="center">&copy;$year $copyright </div>
    </body>
    </html>
    EOD;
        return $page;
}
}

$page='';
$page = Page::addHeader($page,'A Script Using Static Method');
$page .= <<<EOD
<p align="center">This page was generated with static class  
methods</p>
EOD;
$page=Page::addFooter($page,date('Y'),'Static Design INC.');

echo $page;

?>
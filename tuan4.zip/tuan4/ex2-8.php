window.propertag.cmd.push(function() {
                proper_display('sitepoint_content_8');
              });
            
        
<?php      
// Look and feel contains $color and $size      
class LookAndFeel {      
  var $color;      
  var $size;      
  function LookAndFeel()      
  {      
    $this->color = 'white';      
    $this->size = 'medium';      
  }      
  function getColor()      
  {      
    return $this->color;      
  }      
  function getSize()      
  {      
    return $this->size;      
  }      
  function setColor($color)      
  {      
    $this->color = $color;      
  }      
  function setSize($size)      
  {      
    $this->size = $size;      
  }      
}
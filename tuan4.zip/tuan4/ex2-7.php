<?php
class Page{
    var $page;
    var $title;
    var $year;
    var $copyright;
    
    function Page($title,$year,$copyright){
        $this->page='';
        $this->title=$title;
        $this->year=$year;
        $this->copyright=$copyright;

        $this->addHeader();
    }
    function addHeader()
    {
        $this->page .= <<<EOD
        <html>
        <head>
        <title>$this->title</title>
        </head>
        <body>
        <h1 align="center">$this->title</h1>
        EOD;
    }


    function addContent($content){
        $this->page.=$content;
    }

    function addFooter()
    {
        $this->page .= <<<EOD
        <div align="center">&copy;$this->year $this->copyright </div>
        </body>
        </html>
        EOD;
    }

    function get(){
            // Keep a copy of $page with no footer    
        $temp = $this->page;    
        
        // Call the addFooter() method    
        $this->addFooter();    
        
        // Restore $page for the next call to get    
        $page = $this->page;    
        $this->page = $temp;    
    
    return $page;   
    }

    }

    // Instantiate the page class     
$webPage = new Page('As Easy as it Gets', date('Y'),     
'Easy Systems Inc.');     
   
// Add something to the body of the page     
$webPage->addContent("<p align='center'>It's so easy to use!</p>");     
   
// Display the page     
echo $webPage->get();     
?>
